package com.icici;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MayurIciciApplicationTests {

	@Test
	void contextLoads() {
	}

}
