package com.icici.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.icici.services.RestNewServices;

@RestController
@RequestMapping("/send")
public class RestNewController {

	@Autowired
	RestNewServices restNewServices;

	@PostMapping("/sms")
	public ResponseEntity<String> sendSMS2() {

		System.out.println("inside controller");

		return restNewServices.sendSMS();
	}

}
