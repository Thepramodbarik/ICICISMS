package com.icici.services;

import javax.print.DocFlavor.STRING;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;


@Service
public class RestNewServices {

	@Autowired
	private RestTemplate restTemplate;

	public ResponseEntity<String> sendSMS() {
		System.out.println("inside service method===============");


		String sms = "{\"xmlstring\":\"<DEPT>ACG</DEPT><APPID>ACGOI</APPID><MOBILE>917208546563</MOBILE><DEPTMSGID>102</DEPTMSGID><MESSAGE>Dear Customer, your transaction of INR 700000.00 on ICICI Bank Credit Card XX0000 is declined due to insufficient limit. Limit available: INR 2.00</MESSAGE><FROMDATETIME></FROMDATETIME><TODATETIME></TODATETIME><NODELIVERYTIMEFROM></NODELIVERYTIMEFROM><NODELIVERYTIMETO></NODELIVERYTIMETO><HTTPMODE>N</HTTPMODE><REMARKS></REMARKS><TRN_GENERATE_TIMESTAMP></TRN_GENERATE_TIMESTAMP><DUPLICATE_CHECK>N</DUPLICATE_CHECK><REMARKS1>PROMO</REMARKS1><REMARKS2>317</REMARKS2>\"}";
		// String sms ="pramod";
		// String sms="xmlstring^`!<DEPT>ACG</DEPT><APPID>ACGOI</APPID><MOBILE>917208546563</MOBILE><DEPTMSGID>102</DEPTMSGID><MESSAGE>Dear Customer, your transaction of INR 700000.00 on ICICI Bank Credit Card XX0000 is declined due to insufficient limit. Limit available: INR 2.00</MESSAGE><FROMDATETIME></FROMDATETIME><TODATETIME></TODATETIME><NODELIVERYTIMEFROM></NODELIVERYTIMEFROM><NODELIVERYTIMETO></NODELIVERYTIMETO><HTTPMODE>N</HTTPMODE><REMARKS></REMARKS><TRN_GENERATE_TIMESTAMP></TRN_GENERATE_TIMESTAMP><DUPLICATE_CHECK>N</DUPLICATE_CHECK><REMARKS1>PROMO</REMARKS1><REMARKS2>317</REMARKS2>#END#";

		ResponseEntity<String> response = restTemplate.postForEntity("https://httpbin.org/post", sms, String.class);
		System.out.println("test================" + response);
		return response;
	}

}
